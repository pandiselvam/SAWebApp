package com.proj07.sa.cs.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class SAServiceResponse {

	private boolean success;
	private String message;
	private SAResponseData<?> saResponseData;

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("SAServiceResponse::- success:").append(this.success);
		sb.append(" message:").append(this.message);
		sb.append(" saResponseData:").append(this.saResponseData.toString());
		return sb.toString();
	}
}
