package com.proj07.sa.cs.response;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
public abstract class SAResponseData<T> {

	public String responseCode;
	public String responseDesc;
	public int totalCount;
	public T responseData;

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("SAResponseData:-  responseCode:").append(this.responseCode);
		sb.append(" responseDesc:").append(this.responseDesc);
		sb.append(" totalCount:").append(this.totalCount);
		sb.append(" responseData:").append(this.responseData);
		return sb.toString();
	}

}
