package com.proj07.sa.cs.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.proj07.sa.cs.response.SAResponseData;
import com.proj07.sa.cs.response.SAServiceResponse;

@Component
public class APIResponseUtil {

	Logger log = LoggerFactory.getLogger(SAServiceResponse.class);

	public SAServiceResponse buildSuccessResponse(SAResponseData data) {
		SAServiceResponse saServiceResponse = new SAServiceResponse(true, "Request processed successfully", data);
		log.info(saServiceResponse.toString());
		return saServiceResponse;
	}

	public SAServiceResponse buildErrorResponse(String message) {
		SAServiceResponse saServiceResponse = new SAServiceResponse(false, message, null);
		log.info(saServiceResponse.toString());
		return saServiceResponse;
	}
	
	public SAServiceResponse buildErrorResponse(SAResponseData data) {
		SAServiceResponse saServiceResponse = new SAServiceResponse(false, "Request processed with Exception", data);
		log.info(saServiceResponse.toString());
		return saServiceResponse;
	}


	public String getJsonFromDTO(Object object) throws JsonProcessingException {
		String resultJson = "";
		ObjectMapper objectMapper = new ObjectMapper();
		resultJson = objectMapper.writeValueAsString(object);
		return resultJson;
	}
}
