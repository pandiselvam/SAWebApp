package com.proj07.sa.cs.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.proj07.sa.cs.response.SAServiceResponse;

@RestControllerAdvice
public class GlobalExceptionHandler {

	Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

	@Autowired
	private APIResponseUtil apiResponseUtil;

	@ExceptionHandler(Exception.class)
	public ResponseEntity<SAServiceResponse> handleException(Exception ex) {
		SAServiceResponse response = apiResponseUtil.buildErrorResponse(ex.getMessage());
		log.error(ex.getMessage(), ex);
		return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
