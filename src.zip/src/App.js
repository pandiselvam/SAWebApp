import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import LoginPage from "./pages/login/LoginPage";
import HomePage from "./HomePage";
import ResourceListPage from "./pages/appraisal/ResourceListPage";


export default function App() {
  const [selectedResource, setSelectedResource] = useState(null);
  const [loggedInUser, setLoggedInUser] = useState(null);

  return (
    <Router>
      <Routes>
        <Route path="/" element={<LoginPage  setLoggedInUser={setLoggedInUser} />} />
        <Route path="/resources" element={<ResourceListPage setSelectedResource={setSelectedResource} />} />
        <Route path="/home/*" element={<HomePage selectedResource={selectedResource} loggedInUser={loggedInUser} />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </Router>
  );
}
