import React, { useState } from "react";
import { Routes, Route, NavLink, useNavigate } from "react-router-dom";
import PositionPage from "./pages/appraisal/PositionPage";
import CompanyPage from "./pages/appraisal/CompanyPage";
import SummaryPage from "./pages/appraisal/SummaryPage";
import ReviewPage from "./pages/appraisal/ReviewPage";
import ResourceListPage from "./pages/appraisal/ResourceListPage";
import "./HomePage.css";   // 👈 Import CSS

export default function HomePage() {
    const navigate = useNavigate();
    const [step, setStep] = useState(1);
    const [username] = useState("John Doe");

    const handleSaveLater = () => {
        alert("Data saved for later submission!");
    };

    const handleSubmit = () => {
        alert("Form submitted for approval!");
    };

    const [positionRows, setPositionRows] = useState([
        {
            key: "",
            description: "",
            weightage: 5,
            selfComments: "",
            selfRanking: "",
            approverComments: "",
            approverRanking: "",
        },
    ]);

    const [companyRows, setCompanyRows] = useState([
        { key: "", description: "", weightage: 5, selfComments: "", selfRanking: "", approverComments: "", approverRanking: "" },
        { key: "", description: "", weightage: 5, selfComments: "", selfRanking: "", approverComments: "", approverRanking: "" },
        { key: "", description: "", weightage: 5, selfComments: "", selfRanking: "", approverComments: "", approverRanking: "" },
        { key: "", description: "", weightage: 5, selfComments: "", selfRanking: "", approverComments: "", approverRanking: "" },
        { key: "", description: "", weightage: 5, selfComments: "", selfRanking: "", approverComments: "", approverRanking: "" }
    ]);

    const [summary, setSummary] = useState({
        selfRating: "",
        selfComments: "",
        approverRating: "",
        approverComments: ""
    });

    const [selectedResource, setSelectedResource] = useState(null);

    return (
        <div className="homepage">
            {/* --- Top Band --- */}
            <header className="topband">
                <div className="topband-row">
                    <div className="topband-left">
                        <img src="/logo192.png" alt="Company Logo" className="topband-logo" />
                        <h1 className="topband-title">Rel Technologies</h1>
                    </div>
                    <div className="topband-user">👤 {username}</div>
                </div>

                {/* Line 2: Breadcrumbs on left, Global Buttons on right */}
                <div className="topband-row">
                    <nav className="breadcrumbs">
                        <NavLink to="/home/position" className={step === 1 ? "active" : ""}>Position</NavLink>
                        <NavLink to="/home/company" className={step === 2 ? "active" : ""}>Company</NavLink>
                        <NavLink to="/home/summary" className={step === 3 ? "active" : ""}>Summary</NavLink>
                        <NavLink to="/home/review" className={step === 4 ? "active" : ""}>Review</NavLink>
                    </nav>

                    <div className="top-buttons">
                        <button onClick={handleSaveLater}>Save & Submit Later</button>
                        <button onClick={handleSubmit}>Submit for Approval</button>
                    </div>
                </div>
            </header>

            {/* --- Page Content --- */}
            <div className="page-content">
                <Routes>
                    <Route path="position" element={<PositionPage step={step} setStep={setStep} rows={positionRows} setRows={setPositionRows} />} />
                    <Route path="company" element={<CompanyPage step={step} setStep={setStep} rows={companyRows} setRows={setCompanyRows} />} />
                    <Route path="summary" element={<SummaryPage step={step} setStep={setStep} summary={summary} setSummary={setSummary} />} />
                    <Route path="review" element={<ReviewPage step={step} setStep={setStep} positionRows={positionRows} companyRows={companyRows} summary={summary} />} />
                    <Route path="resources" element={<ResourceListPage setSelectedResource={setSelectedResource} />} />
                </Routes>
            </div>
        </div>
    );
}
