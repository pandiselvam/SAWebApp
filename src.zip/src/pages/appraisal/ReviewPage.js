// ReviewPage.js
import React from "react";
import { useNavigate } from "react-router-dom";
import "./ReviewPage.css";

export default function ReviewPage({ setStep, positionRows, companyRows, summary }) {
  const navigate = useNavigate();
  const show = (v) => (v && String(v).trim().length ? v : "—");

  const handleBack = () => {
    setStep(3);
    navigate("/home/summary");
  };

  return (
    <div className="page-container">
      <h2 className="page-title">Review & Confirm</h2>
      <p className="page-description">
        Please review all your inputs (read-only). Use Back to edit anything.
      </p>

      {/* Position */}
      <h3 className="section-title">Position Based Performance Points</h3>
      <div className="review-table">
        {positionRows.map((row, i) => (
          <div key={i} className="review-row">
            <div className="review-field"><strong>Key:</strong> {show(row.key)}</div>
            <div className="review-field"><strong>Description:</strong> {show(row.description)}</div>
            <div className="review-field"><strong>Weightage:</strong> {show(row.weightage)}</div>
            <div className="review-field"><strong>Self Comments:</strong> {show(row.selfComments)}</div>
            <div className="review-field"><strong>Self Ranking:</strong> {show(row.selfRanking)}</div>
            <div className="review-field"><strong>Approver Comments:</strong> {show(row.approverComments)}</div>
            <div className="review-field"><strong>Approver Ranking:</strong> {show(row.approverRanking)}</div>
          </div>
        ))}
      </div>

      {/* Company */}
      <h3 className="section-title">Company Based Performance Points</h3>
      <div className="review-table">
        {companyRows.map((row, i) => (
          <div key={i} className="review-row">
            <div className="review-field"><strong>Key:</strong> {show(row.key)}</div>
            <div className="review-field"><strong>Description:</strong> {show(row.description)}</div>
            <div className="review-field"><strong>Weightage:</strong> {show(row.weightage)}</div>
            <div className="review-field"><strong>Self Comments:</strong> {show(row.selfComments)}</div>
            <div className="review-field"><strong>Self Ranking:</strong> {show(row.selfRanking)}</div>
            <div className="review-field"><strong>Approver Comments:</strong> {show(row.approverComments)}</div>
            <div className="review-field"><strong>Approver Ranking:</strong> {show(row.approverRanking)}</div>
          </div>
        ))}
      </div>

      {/* Overall Summary */}
      <h3 className="section-title">Overall Summary</h3>
      <div className="review-table">
        <div className="review-row">
          <div className="review-field"><strong>Self Rating:</strong> {show(summary.selfRating)}</div>
          <div className="review-field"><strong>Overall Self Comments:</strong> {show(summary.selfComments)}</div>
          <div className="review-field"><strong>Approver Rating:</strong> {show(summary.approverRating)}</div>
          <div className="review-field"><strong>Approver Overall Comments:</strong> {show(summary.approverComments)}</div>
        </div>
      </div>

      <div className="nav-buttons">
        <button className="btn btn-back" onClick={handleBack}>⬅ Back</button>
        {/* No Next here; top-band has Save/Submit buttons */}
      </div>
    </div>
  );
}
