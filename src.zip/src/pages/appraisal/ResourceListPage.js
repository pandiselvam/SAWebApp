import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./ResourceListPage.css";

const initialResources = [
  {
    id: "R001",
    name: "John Doe",
    prevYearRating: "ME",
    lastYearRating: "EE",
    selfStatus: "Pending",
    selfDue: "2025-09-15",
    approverStatus: "Not Started",
    approverDue: "2025-09-25",
    finalRating: "-",
    finalDue: "2025-10-01",
  },
  {
    id: "R002",
    name: "Jane Smith",
    prevYearRating: "ND",
    lastYearRating: "ME",
    selfStatus: "Completed",
    selfDue: "2025-09-10",
    approverStatus: "In Review",
    approverDue: "2025-09-20",
    finalRating: "-",
    finalDue: "2025-09-28",
  },
  // add more resources as needed
];

export default function ResourceListPage({ setSelectedResource }) {
  const [resources] = useState(initialResources);
  const [username] = useState("John Doe");
  const navigate = useNavigate();

  const handleSelect = (resource) => {
    setSelectedResource(resource); // store selected resource
    navigate("/home/position");   // start workflow from Position page
  };

  return (
    <>
      <header className="topband">
        <div className="topband-row">
          <div className="topband-left">
            <img src="/logo192.png" alt="Company Logo" className="topband-logo" />
            <h1 className="topband-title">Rel Technologies</h1>
          </div>
          <div className="topband-user">👤 {username}</div>
        </div>
      </header>
      <div className="page-container">
        <h2 className="page-title">Resource List</h2>
        <p className="page-description">Select a resource to begin appraisal workflow</p>

        <div className="resource-table">
          <div className="resource-header">
            <span>Resource ID</span>
            <span>Name</span>
            <span>Prev Yr Rating</span>
            <span>Last Yr Rating</span>
            <span>Self Status</span>
            <span>Self Due Date</span>
            <span>Approver Status</span>
            <span>Approver Due Date</span>
            <span>Final Rating</span>
            <span>Final Due Date</span>
            <span>Action</span>
          </div>

          {resources.map((res) => (
            <div key={res.id} className="resource-row">
              <span>{res.id}</span>
              <span>{res.name}</span>
              <span>{res.prevYearRating}</span>
              <span>{res.lastYearRating}</span>
              <span>{res.selfStatus}</span>
              <span>{res.selfDue}</span>
              <span>{res.approverStatus}</span>
              <span>{res.approverDue}</span>
              <span>{res.finalRating}</span>
              <span>{res.finalDue}</span>
              <button onClick={() => handleSelect(res)}>Select</button>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
