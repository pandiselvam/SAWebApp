import React from "react";
import { useNavigate } from "react-router-dom";
import "./PositionPage.css"

const rankingOptions = [
  "EE - Exceeded Expectation",
  "ME - Met Expectation",
  "ND - Need Development",
  "PIP - Performance Improvement Plan",
];

const weightageOptions = [5, 10, 20, 30];

export default function CompanyPage({ setStep, rows, setRows }) {
  const navigate = useNavigate();

  const handleChange = (index, field, value) => {
    const updated = [...rows];
    updated[index][field] = value;
    setRows(updated);
  };

  const handleNext = () => {
    setStep(3);
    navigate("/home/summary");
  };

  const handleBack = () => {
    setStep(1);
    navigate("/home/position");
  };

  return (
    <div className="page-container">
      <h2 className="page-title">Company Based Performance Points</h2>
      <p className="page-description">
        Provide inputs for company-wide performance evaluation.
      </p>

      <div className="table-container">
        {rows.map((row, index) => (
          <div key={index} className="table-row">
            <input
              type="text"
              placeholder="Key"
              value={row.key}
              onChange={(e) => handleChange(index, "key", e.target.value)}
            />

            <textarea
              placeholder="Description"
              value={row.description}
              onChange={(e) => handleChange(index, "description", e.target.value)}
            />

            <select
              value={row.weightage}
              onChange={(e) => handleChange(index, "weightage", e.target.value)}
            >
              {weightageOptions.map((w) => (
                <option key={w} value={w}>
                  {w}
                </option>
              ))}
            </select>

            <textarea
              placeholder="Self Comments"
              value={row.selfComments}
              onChange={(e) => handleChange(index, "selfComments", e.target.value)}
            />

            <select
              value={row.selfRanking}
              onChange={(e) => handleChange(index, "selfRanking", e.target.value)}
            >
              <option value="">Select</option>
              {rankingOptions.map((r, i) => (
                <option key={i} value={r}>
                  {r}
                </option>
              ))}
            </select>

            <textarea
              placeholder="Approver Comments"
              value={row.approverComments}
              disabled
            />

            <select value={row.approverRanking} disabled>
              <option value="">Select</option>
              {rankingOptions.map((r, i) => (
                <option key={i} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </div>
        ))}
      </div>

      <div className="nav-buttons">
        <button className="btn btn-back" onClick={handleBack}>
          ⬅ Back
        </button>
        <button className="btn btn-next" onClick={handleNext}>
          Next ➡
        </button>
      </div>
    </div>
  );
}
