const APP_BASE_URL = "http://localhost:8081/sa-api/appraisal/v1";

const API_ENDPOINTS = {
    VALIDATE_LOGIN: `${APP_BASE_URL}/login`,
    LANDING_PAGE: `${APP_BASE_URL}/landing/page`
  };
  
  export default API_ENDPOINTS; 