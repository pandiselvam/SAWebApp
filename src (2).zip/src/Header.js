import React from "react";
import { useNavigate } from "react-router-dom";
import { FaHome, FaSignOutAlt } from "react-icons/fa"; // icons

function Header({ userName, role }) {
  const navigate = useNavigate();

  const handleHome = () => {
    // if needed: role-based landing
    if (role === "Manager") {
      navigate("/resources", { state: { userName, role } });
    } else {
      navigate("/home/position", { state: { userName, role } });
    }
  };

  const handleLogout = () => {
    // clear local/session storage if used
    localStorage.clear();
    navigate("/"); // back to login
  };

  return (
    <header style={styles.header}>
      <div style={styles.left}>
        <img src="/logo192.png" alt="Company Logo" style={styles.logo} />
        <h2 style={styles.company}>My Company</h2>
      </div>

      <div style={styles.center}>
        <span style={styles.userInfo}>
          {userName} ({role})
        </span>
      </div>

      <div style={styles.right}>
        <FaHome onClick={handleHome} style={styles.icon} title="Home" />
        <FaSignOutAlt onClick={handleLogout} style={styles.icon} title="Log Off" />
      </div>
    </header>
  );
}

const styles = {
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "10px 20px",
    backgroundColor: "#1E3A8A", // dark blue
    color: "#fff"
  },
  left: { display: "flex", alignItems: "center" },
  logo: { width: "40px", marginRight: "10px" },
  company: { margin: 0 },
  center: { flex: 1, textAlign: "center" },
  userInfo: { fontWeight: "bold" },
  right: { display: "flex", gap: "20px" },
  icon: { cursor: "pointer", fontSize: "20px" }
};

export default Header;
