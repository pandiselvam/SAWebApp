import React from 'react';
import { ClipLoader } from 'react-spinners';

const LoadMask = ({ loading }) => {
  if (!loading) return null;

  return (
    <div style={styles.overlay}>
      <ClipLoader color="#ffffff" size={50} />
    </div>
  );
};

const styles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100vw',
    height: '100vh',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 9999,
  },
};

export default LoadMask;
