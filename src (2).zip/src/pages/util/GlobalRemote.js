import API_ENDPOINTS from "../../env";

export async function validateLogin(userName, passWord) {
    //const queryParams = new URLSearchParams(loginFilters).toString();
    const url = `${API_ENDPOINTS.VALIDATE_LOGIN}`;
    try {
        const response = await fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ userName, passWord })
        });
        const data = await response.json();
        if (!response.ok) throw new Error('Failed to validateLogin');
        return data;
    } catch (error) {
        console.error("Error validateLogin:", error);
    }
};

export async function loadLandingPage(userName) {
    const url = `${API_ENDPOINTS.LANDING_PAGE}?userName=${userName}`;
    try {
        const response = await fetch(url);
        const data = await response.json();
        if (!response.ok) throw new Error('Failed to loadLandingPage');
        return data;
    } catch (error) {
        console.error("Error loadLandingPage:", error);
    }
};