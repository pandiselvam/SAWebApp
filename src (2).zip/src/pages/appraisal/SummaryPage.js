import React from "react";
import { useNavigate } from "react-router-dom";
import "./PositionPage.css"

const rankingOptions = [
  "EE - Exceeded Expectation",
  "ME - Met Expectation",
  "ND - Need Development",
  "PIP - Performance Improvement Plan",
];

export default function SummaryPage({ setStep, summary, setSummary }) {
  const navigate = useNavigate();

  const handleChange = (field, value) => {
    setSummary({ ...summary, [field]: value });
  };

  const handleNext = () => {
    setStep(4);
    navigate("/home/review");
  };

  const handleBack = () => {
    setStep(2);
    navigate("/home/company");
  };

  return (
    <div className="page-container">
      <h2 className="page-title">Overall Summary</h2>
      <p className="page-description">
        Provide your overall self-assessment and rating.
      </p>

      <div className="table-container">
        <div className="table-row summary-row">
          {/* Self Rating */}
          <select
            value={summary.selfRating}
            onChange={(e) => handleChange("selfRating", e.target.value)}
          >
            <option value="">Select Self Rating</option>
            {rankingOptions.map((r, i) => (
              <option key={i} value={r}>
                {r}
              </option>
            ))}
          </select>

          {/* Overall Self Comments */}
          <textarea
            placeholder="Overall Self Comments"
            value={summary.selfComments}
            onChange={(e) => handleChange("selfComments", e.target.value)}
          />

          {/* Approver Rating */}
          <select value={summary.approverRating} disabled>
            <option value="">Select Approver Rating</option>
            {rankingOptions.map((r, i) => (
              <option key={i} value={r}>
                {r}
              </option>
            ))}
          </select>

          {/* Approver Overall Comments */}
          <textarea
            placeholder="Approver Overall Comments"
            value={summary.approverComments}
            disabled
          />
        </div>
      </div>

      <div className="nav-buttons">
        <button className="btn btn-back" onClick={handleBack}>
          ⬅ Back
        </button>
        <button className="btn btn-next" onClick={handleNext}>
          Next ➡
        </button>
      </div>
    </div>
  );
}
