import React, { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { loadLandingPage } from "../util/GlobalRemote";
import "./ResourceListPage.css";

export default function ResourceListPage({ setSelectedResource }) {
  const [resources, setResources] = useState([]);
  const [listRespData, setListRespData] = useState([]);
  const navigate = useNavigate();
  const location = useLocation();
  const { userName, firstName, lastName, role } = location.state || {};

  const handleSelect = (resource) => {
    setSelectedResource(resource);
    navigate("/home/position");
  };

  useEffect(() => {
    const doLanding = async () => {
      const data = await loadLandingPage(userName);
      const responseData1 = JSON.parse(data.saResponseData.responseData);
      setResources(responseData1);
    }
    doLanding();
  }, []);

  return (
    <div className="page-container">
      <h2 className="page-title">Resource List</h2>
      <p className="page-description">Select a resource to begin appraisal workflow</p>

      <div className="resource-table">
        <div className="resource-header">
          <span>S.No</span>
          <span>User Name</span>
          <span>Name</span>
          <span>Role</span>
          <span>Last Yr Rating</span>
          <span>Last Yr Comments</span>
          <span>Last Yr Manager</span>
          <span>Apprisal Status</span>
          <span>Self Due Date</span>
          <span>Approver Due Date</span>
          <span>Final Rating</span>
          <span>Final Due Date</span>
          <span>Action</span>
        </div>

        {resources.map((res, index) => (
          <div key={res.userName} className="resource-row">
            <span>{index + 1}</span>
            <span>{res.userName}</span>
            <span>{res.firstName} {res.lastName}</span>
            <span>{res.role}</span>
            <span>{res.lastyear1Rating}</span>
            <span>{res.lastyear1Comments}</span>
            <span>{res.lastyear1Manager}</span>
            <span>{res.apprisalStatus}</span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <button onClick={() => handleSelect(res)}>Select</button>
          </div>
        ))}
      </div>
    </div>
  );
}
