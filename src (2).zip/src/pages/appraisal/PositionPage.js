import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./PositionPage.css"

const rankingOptions = [
  "EE - Exceeded Expectation",
  "ME - Met Expectation",
  "ND - Need Development",
  "PIP - Performance Improvement Plan",
];

const weightageOptions = [5, 10, 20, 30];

const PositionPage = ({ setStep, rows, setRows }) => {
  const navigate = useNavigate();

  // const [rows, setRows] = useState([
  //   {
  //     key: "",
  //     description: "",
  //     weightage: 5,
  //     selfComments: "",
  //     selfRanking: "",
  //     approverComments: "",
  //     approverRanking: "",
  //   },
  // ]);

  const handleChange = (index, field, value) => {
    const updated = [...rows];
    updated[index][field] = value;
    setRows(updated);
  };

  const addRow = () => {
    setRows([
      ...rows,
      {
        key: "",
        description: "",
        weightage: 5,
        selfComments: "",
        selfRanking: "",
        approverComments: "",
        approverRanking: "",
      },
    ]);
  };

  const deleteRow = (index) => {
    const updated = rows.filter((_, i) => i !== index);
    setRows(updated);
  };

  return (
    <div className="page-container">
      <h2 className="page-title">Position Based Performance Points</h2>
      <p className="page-description">
        Fill in your role-specific performance details below.
      </p>

      <div className="table-container">
        {rows.map((row, index) => (
          <div key={index} className="table-row">
            <input
              type="text"
              placeholder="Key"
              value={row.key}
              onChange={(e) => handleChange(index, "key", e.target.value)}
            />

            <textarea
              placeholder="Description"
              value={row.description}
              onChange={(e) =>
                handleChange(index, "description", e.target.value)
              }
            />

            <select
              value={row.weightage}
              onChange={(e) => handleChange(index, "weightage", e.target.value)}
            >
              {weightageOptions.map((w) => (
                <option key={w} value={w}>
                  {w}
                </option>
              ))}
            </select>

            <textarea
              placeholder="Self Comments"
              value={row.selfComments}
              onChange={(e) =>
                handleChange(index, "selfComments", e.target.value)
              }
            />

            <select
              value={row.selfRanking}
              onChange={(e) =>
                handleChange(index, "selfRanking", e.target.value)
              }
            >
              <option value="">Select</option>
              {rankingOptions.map((r, i) => (
                <option key={i} value={r}>
                  {r}
                </option>
              ))}
            </select>

            <textarea
              placeholder="Approver Comments"
              value={row.approverComments}
              disabled
            />

            <select value={row.approverRanking} disabled>
              <option value="">Select</option>
              {rankingOptions.map((r, i) => (
                <option key={i} value={r}>
                  {r}
                </option>
              ))}
            </select>

            <div className="row-actions">
              <button onClick={addRow}>➕</button>
              {rows.length > 1 && (
                <button onClick={() => deleteRow(index)}>🗑</button>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="nav-buttons">
        <button className="btn btn-next" onClick={() => { setStep(2); navigate("/home/company"); }}>
          Next ➡
        </button>
      </div>
    </div>
  );
};

export default PositionPage;
