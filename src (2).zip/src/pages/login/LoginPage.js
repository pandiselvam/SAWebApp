import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { validateLogin } from "../util/GlobalRemote";
import "./LoginPage.css";
import LoadMask from "../util/LoadMask";

const LoginPage = () => {
  const [loading, setLoading] = useState(false);
  const [userName, setUserName] = useState("");
  const [passWord, setPassWord] = useState("");
  const navigate = useNavigate();


  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const data = await validateLogin(userName, passWord);
      const responseData1 = JSON.parse(data.saResponseData.responseData);
      setLoading(false);
      //alert(responseData1.resourceFlag);
      if (!responseData1.resourceFlag) {
        navigate("/home/position", { state: { userName: responseData1.userName, firstName:responseData1.firstName, lastName:responseData1.lastName, role: responseData1.role } });
      } else {
        navigate("/home/resources", { state: { userName: responseData1.userName, firstName:responseData1.firstName, lastName:responseData1.lastName, role: responseData1.role } });
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleReset = () => {
    setUserName("");
    setPassWord("");
  };

  return (
    <div className="login-container">
      <h2>Employee Self Appraisal - Login</h2>
      <form onSubmit={handleSubmit} className="login-form">
        <div className="form-group">
          <label>Username:</label>
          <input
            type="text"
            value={userName}
            onChange={(e) => setUserName(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label>Password:</label>
          <input
            type="password"
            value={passWord}
            onChange={(e) => setPassWord(e.target.value)}
            required
          />
        </div>

        <div className="form-buttons">
          <button type="submit">Submit</button>
          <button type="button" onClick={handleReset}>Reset</button>
        </div>
      </form>
    </div>
  );
};

export default LoginPage;
