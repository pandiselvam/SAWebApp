package com.proj07.sa.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.proj07.sa.as.dto.LoginReqDTO;
import com.proj07.sa.as.service.SAAppraisalService;
import com.proj07.sa.cs.response.SAServiceResponse;

@RestController
@RequestMapping("/sa-api/appraisal/v1")
@CrossOrigin(origins = "http://localhost:3000")
public class SAAppraisalController {

	Logger log = LoggerFactory.getLogger(SAAppraisalController.class);

	@Autowired
	private SAAppraisalService appraisalService;

	@PostMapping("/login")
	public SAServiceResponse validateLogin(@RequestBody LoginReqDTO loginReqDTO) {
		log.info("validateLogin: {}, {}", loginReqDTO.getUserName(), loginReqDTO.getPassWord());
		SAServiceResponse saServiceResponse = appraisalService.validateUser(loginReqDTO.getUserName(),
				loginReqDTO.getPassWord());
		return saServiceResponse;
	}

	@GetMapping("/landing/page")
	public SAServiceResponse loadLandingPage(@RequestParam String userName) {
		log.info("loadLandingPage: {}", userName);
		SAServiceResponse saServiceResponse = appraisalService.loadFirstPage(userName);
		return saServiceResponse;
	}

}
