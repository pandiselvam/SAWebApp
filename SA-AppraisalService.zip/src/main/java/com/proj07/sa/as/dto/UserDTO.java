package com.proj07.sa.as.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDTO {

	private Long recId;
	private String userId;
	private String userName;
	private String firstName;
	private String lastName;
	private String role;
	private String password;
	private String apprisalStatus;
	private String rating;
	private Integer points;
	private String comments;

	private String lastyear1Rating;
	private Integer lastyear1Points;
	private String lastyear1Comments;
	private String lastyear1Manager;

	private String lastyear2Rating;
	private Integer lastyear2Points;
	private String lastyear2Comments;
	private String lastyear2Manager;
	private boolean resourceFlag;
	private String goalStatus;
	private String reportingManager;
	
	
}