package com.proj07.sa.as.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.proj07.sa.as.dto.PageLoadFilterDTO;
import com.proj07.sa.as.dto.UserDTO;
import com.proj07.sa.as.repo.SAAppraisalRepositary;
import com.proj07.sa.as.repo.UserEntity;
import com.proj07.sa.cs.handler.APIResponseUtil;
import com.proj07.sa.cs.response.SAServiceResponse;

@Service
public class SAAppraisalService {

	Logger log = LoggerFactory.getLogger(SAAppraisalService.class);

	@Autowired
	private SAAppraisalRepositary saAppraisalRepositary;

	@Autowired
	private APIResponseUtil aPIResponseUtil;
	
	@Autowired
	private SAAppraisalHandler saAppraisalHandler;

	/**
	 * Validate the user by username and password.
	 * 
	 * @param userName the login username
	 * @param passWord the login password
	 * @return UserEntity if valid, otherwise null
	 */
	public SAServiceResponse validateUser(String userName, String passWord) {
		int length = 0;
		UserDTO userDto = null;

		String userInfo = "";
		String resultJson = "";
		Optional<UserEntity> userOpt = saAppraisalRepositary.findByUserNameAndPassword(userName, passWord);

		if (userOpt.isPresent()) {
			List<UserEntity> subordinates = saAppraisalRepositary.findByReportingManager(userName);
			log.info("Reportees count for {} is {}, {}", userName, subordinates.size(), subordinates);
			if (subordinates.size() == 0) {
			
			UserEntity entity = userOpt.get();
			userDto = saAppraisalHandler.mapToDto(entity);
			userDto.setResourceFlag(getResourceFlag(userName));
			length = 1;
			try {
				userInfo = aPIResponseUtil.getJsonFromDTO(userDto);
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
			resultJson = userInfo;
			SAResponse<String> saResponse = new SAResponse<String>("0", "success", length, resultJson);
			return aPIResponseUtil.buildSuccessResponse(saResponse);
		} else {
			log.debug("User Name: '{}' was not found.", userName);
			SAResponse<String> saResponse = new SAResponse<String>("100", "failure", 0,
					"User Name/Password is not Found");
			return aPIResponseUtil.buildErrorResponse(saResponse);
		}
	}

	public boolean getResourceFlag(String userName) {
		List<UserEntity> subordinates = saAppraisalRepositary.findByReportingManager(userName);
		log.info("Reportees count for {} is {}, {}", userName, subordinates.size(), subordinates);
		if (subordinates.size() == 0) {
			return false;
		} else
			return true;
	}

	public SAServiceResponse loadFirstPage(String userName) {
		int length = 0;
		PageLoadFilterDTO pageLoadFilterDTO = new PageLoadFilterDTO();

		String userInfo = "";
		String resultJson = "";

		List<UserEntity> subordinates = saAppraisalRepositary.findByReportingManager(userName);
		log.info("Reportees count for {} is {}, {}", userName, subordinates.size(), subordinates);
		if (subordinates.size() == 0) {
			boolean goalStatus = saAppraisalRepositary.existsByUserNameAndGoalStatus(userName, "completed");
			if (goalStatus) {
				pageLoadFilterDTO.setGoalStatus(goalStatus);
				pageLoadFilterDTO.setGoalSettingTab(false);
				String appStatus = saAppraisalRepositary.findApprisalStatusByUserName(userName);
				log.info("Appraisal Status of {} is {}", userName, appStatus);
				if (appStatus == null || "progress".equalsIgnoreCase(appStatus) || "Open".equalsIgnoreCase(appStatus)) {
					pageLoadFilterDTO.setSelfAppraisalTab(true);
					pageLoadFilterDTO.setApproverTab(false);
					pageLoadFilterDTO.setPopupMessage("Please update your self performance rating");
				} else if (appStatus != null && "submitted".equalsIgnoreCase(appStatus)) {
					pageLoadFilterDTO.setSelfAppraisalTab(false);
					pageLoadFilterDTO.setApproverTab(false);
					pageLoadFilterDTO.setPopupMessage(
							"Your Self Appraisal has been submitted to the Reporting Manager for Approval.");
				}
				try {
					userInfo = aPIResponseUtil.getJsonFromDTO(pageLoadFilterDTO);
				} catch (JsonProcessingException e) {
					e.printStackTrace();
				}
				SAResponse<String> saResponse = new SAResponse<String>("0", "success", 1, userInfo);
				return aPIResponseUtil.buildSuccessResponse(saResponse);
			} else {
				SAResponse<String> saResponse = new SAResponse<String>("100", "failure", 0,
						"Goal setting is not yet completed. Please check with Manager");
				return aPIResponseUtil.buildSuccessResponse(saResponse);
			}
		} else {
			List<UserDTO> listUserDto = saAppraisalHandler.updateStatus(subordinates);
			try {
				userInfo = aPIResponseUtil.getJsonFromDTO(listUserDto);
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}
			SAResponse<String> saResponse = new SAResponse<String>("0", "success", 1, userInfo);
			return aPIResponseUtil.buildSuccessResponse(saResponse);
		}
	}

}
