package com.proj07.sa.as;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.proj07.sa")
public class SAAppraisalApplication {

	public static void main(String[] args) {
		SpringApplication.run(SAAppraisalApplication.class, args);
	}

}
