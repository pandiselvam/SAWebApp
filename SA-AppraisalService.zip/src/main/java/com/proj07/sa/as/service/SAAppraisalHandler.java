package com.proj07.sa.as.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.proj07.sa.as.dto.UserDTO;
import com.proj07.sa.as.repo.UserEntity;

@Component
public class SAAppraisalHandler {

	public List<UserDTO> updateStatus(List<UserEntity> userEntityList) {
		List<UserDTO> resultList = new ArrayList<UserDTO>();
		UserDTO userDto = null;
		for (int i = 0; i < userEntityList.size(); i++) {
			UserEntity entity = userEntityList.get(i);
			userDto = mapToDto(entity);
			String goalStatus = userDto.getGoalStatus();
			String appraisalStatus = userDto.getApprisalStatus();

			if (goalStatus == null) {
				userDto.setGoalStatus("Goal Setup is pending with Manager");
				userDto.setApprisalStatus("Goal Setup is pending with Manager");
				if ("Completed".equalsIgnoreCase(goalStatus)) {
					if (appraisalStatus == null || "open".equalsIgnoreCase(appraisalStatus)) {
						userDto.setApprisalStatus("Self Appraisal is in progress");
					} else if ("submitted".equalsIgnoreCase(appraisalStatus)) {
						userDto.setApprisalStatus("Manager Approval is in progress");
					} else if ("approved".equalsIgnoreCase(appraisalStatus)) {
						userDto.setApprisalStatus("Management Moderation is in progress");
					}
				}
			}
			resultList.add(userDto);
		}
		return resultList;
	}

	public UserDTO mapToDto(UserEntity entity) {
		UserDTO dto = new UserDTO();
		dto.setRecId(entity.getRecId());
		dto.setUserId(entity.getUserId());
		dto.setUserName(entity.getUserName());
		dto.setFirstName(entity.getFirstName());
		dto.setLastName(entity.getLastName());
		dto.setRole(entity.getRole());
		dto.setApprisalStatus(entity.getApprisalStatus());
		dto.setRating(entity.getRating());
		dto.setPoints(entity.getPoints());
		dto.setComments(entity.getComments());
		dto.setLastyear1Rating(entity.getLastyear1Rating());
		dto.setLastyear1Points(entity.getLastyear1Points());
		dto.setLastyear1Comments(entity.getLastyear1Comments());
		dto.setLastyear1Manager(entity.getLastyear1Manager());
		dto.setLastyear2Rating(entity.getLastyear2Rating());
		dto.setLastyear2Points(entity.getLastyear2Points());
		dto.setLastyear2Comments(entity.getLastyear2Comments());
		dto.setLastyear2Manager(entity.getLastyear2Manager());
		return dto;
	}
}
