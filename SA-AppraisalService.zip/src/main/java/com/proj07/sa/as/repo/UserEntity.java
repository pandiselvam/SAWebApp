package com.proj07.sa.as.repo;


import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "users_mb")
public class UserEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "rec_id")
    private Long recId;

    @Column(name = "user_id", nullable = false, unique = true)
    private String userId;

    @Column(name = "user_name", nullable = false, unique = true)
    private String userName;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "role")
    private String role;

    @Column(name = "pass_word")
    private String password;

    @Column(name = "apprisal_status")
    private String apprisalStatus;

    @Column(name = "rating")
    private String rating;

    @Column(name = "points")
    private Integer points;

    @Column(name = "comments")
    private String comments;

    @Column(name = "lastyear1_rating")
    private String lastyear1Rating;

    @Column(name = "lastyear1_points")
    private Integer lastyear1Points;

    @Column(name = "lastyear1_comments")
    private String lastyear1Comments;

    @Column(name = "lastyear1_manager")
    private String lastyear1Manager;

    @Column(name = "lastyear2_rating")
    private String lastyear2Rating;

    @Column(name = "lastyear2_points")
    private Integer lastyear2Points;

    @Column(name = "lastyear2_comments")
    private String lastyear2Comments;

    @Column(name = "lastyear2_manager")
    private String lastyear2Manager;
    
    @Column(name = "goal_status")
    private String goalStatus;
    
    @Column(name = "reporting_manager")
    private String reportingManager;



}

