package com.proj07.sa.as.service;

import com.proj07.sa.cs.response.SAResponseData;

public class SAResponse<T> extends SAResponseData {

	public SAResponse(String responseCode, String responseDesc, int totalCount, T responseData) {
		super(responseCode, responseDesc, totalCount, responseData);
	}
}
