package com.proj07.sa.as.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface SAAppraisalRepositary extends JpaRepository<UserEntity, Long> {

	Optional<UserEntity> findByUserNameAndPassword(String userName, String passWord);
	
	boolean existsByUserNameAndGoalStatus(String userName, String goalStatus);
	
	@Query("SELECT u.apprisalStatus FROM UserEntity u WHERE u.userName = :userName")
	String findApprisalStatusByUserName(@Param("userName") String userName);
	
	@Query("SELECT u FROM UserEntity u WHERE u.reportingManager = :userName")
	List<UserEntity> findByReportingManager(@Param("userName") String userName);
	
}
