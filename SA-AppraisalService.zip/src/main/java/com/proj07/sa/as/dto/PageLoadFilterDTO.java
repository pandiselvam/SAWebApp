package com.proj07.sa.as.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class PageLoadFilterDTO {

	private boolean goalStatus;
	private boolean goalSettingTab;
	private boolean selfAppraisalTab;
	private boolean approverTab;
	private String popupMessage;
}