package com.proj07.sa.cf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.config.server.EnableConfigServer;

@SpringBootApplication
@EnableConfigServer
public class SAConfigService {

	public static void main(String[] args) {
		//System.setProperty("spring.profiles.active", "native"); 
		SpringApplication.run(SAConfigService.class, args);
	}

}
